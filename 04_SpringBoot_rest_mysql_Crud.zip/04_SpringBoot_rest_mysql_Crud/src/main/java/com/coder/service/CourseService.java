package com.coder.service;

import java.util.List;

import com.coder.binding.Course;

public interface CourseService {
	
	public String upsert(Course course);
	
	public Course getById(Integer cid);
	
	public List<Course> getAllCourses();
	
	public String deletedById(Integer cid);
	
	

}
